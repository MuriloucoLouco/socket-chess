var socket = io();

function preload() {
    images = {
        'pw': loadImage('images/pw'),
        'pb' :loadImage('images/pb'),
        'kw' :loadImage('images/kw'),
        'kb' :loadImage('images/kb'),
        'nw' :loadImage('images/nw'),
        'nb' :loadImage('images/nb'),
        'bw' :loadImage('images/bw'),
        'bb' :loadImage('images/bb'),
        'qw' :loadImage('images/qw'),
        'qb' :loadImage('images/qb'),
        'rw' :loadImage('images/rw'),
        'rb' :loadImage('images/rb'),
        ''   :loadImage('images/blank'), 
    }
}

function setup() {
    createCanvas(360, 360);
}
var positions;

socket.on('sendPositions', (data) => {
    positions = data;
});

function sendMove(initial, final) {
    socket.emit('move', {initial, final});
}

function draw() {
    background(128);
    for (let i = 0; i < 8; i++) {
        for (let k = 0; k < 8; k++) {
            let color;
            if (i % 2 === 0){ color = 0 }
            else { color = 1 }
            if (k % 2 === color) { fill(255); square(45*i, 45*k, 45) }
            else { fill(128); square(45*i, 45*k, 45) }
            
            image(images[positions[k][i]], 45*i, 45*k)
        }
    }
    
}