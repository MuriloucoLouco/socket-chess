const app = require('express')();
const http = require('http');
const server = http.createServer(app);
const PORT = process.env.PORT || 3000;
const io = require('socket.io')(server);
const { addUser, removeUser, getUser, getUsersInRoom } = require('./users.js');

app.get('/', (req, res) => {
    res.sendFile(__dirname+'/index.html');
});

app.get('/script.js', (req, res) => {
    res.sendFile(__dirname+'/script.js');
});

app.get('/images/:file', (req, res) => {
    try { res.sendFile(__dirname+'/images/'+req.params['file']+'.png');}
    catch (error) { console.log(error) }
});

function checkMoveValidity (positions, initial, final) {
    return true;
}
roomlist = [0]
io.on('connection', (socket) => {

    for (i = 0; i < roomlist.length; i++) {
        if (getUsersInRoom(roomlist[i]))
        const user = addUser({ id: socket.id, roomlist[i] });
    }
    

    let positions = [
        ['rb', 'nb', 'bb', 'qb', 'kb', 'bb', 'nb', 'rb'],
        ['pb', 'pb', 'pb', 'pb', 'pb', 'pb', 'pb', 'pb'],
        ['', '', '', '', '', '', '', ''],
        ['', '', '', '', '', '', '', ''],
        ['', '', '', '', '', '', '', ''],
        ['', '', '', '', '', '', '', ''],
        ['pw', 'pw', 'pw', 'pw', 'pw', 'pw', 'pw', 'pw'],
        ['rw', 'nw', 'bw', 'qw', 'kw', 'bw', 'nw', 'rw']
    ];

    socket.emit('sendPositions', positions);

    socket.on('move', ({ initial, final }) => {
        const user = getUser(socket.id);
        if (checkMoveValidity(positions, initial, final) === true) {
            positions[final[1]][final[0]] = positions[initial[1]][initial[0]];
            positions[initial[1]][initial[0]] = '';
            io.to(user.room).emit('sendPositions', positions);
        }
    });
    
    socket.on('disconnect', () => {
        removeUser(socket.id);
        console.log('Usuário meteu o pé.', socket.id);
    });
});

server.listen(PORT, () => {
    console.log('Servidor rodando em:', PORT);
});